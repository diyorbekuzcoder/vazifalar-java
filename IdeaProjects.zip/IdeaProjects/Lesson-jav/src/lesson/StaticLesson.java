package lesson;
import java.util.Scanner;

public class StaticLesson {


    static{
        System.out.println("static block");
//        System.exit(1);
    }


    public static void main(String[] args) {

       StaticLesson lesson = new StaticLesson();
       lesson.display();
       int sum = Calculate.sum(10,7);
       System.out.println(sum);
    }



    public void display(){
        System.out.println("static keyword");
    }
}
