package lesson;

public class CharDataTaype {
    public static void main(String[] args) {
        char u= '\u0044';
        System.out.println(u);
    }
}
