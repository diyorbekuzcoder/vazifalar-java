package lesson;

public class StringDataType {
    public static void main(String[] args) {

        String text = "Hello Narin, Hello iluqwgcbi Hello , ughefub Hello , juegfilbc";
        System.out.println(text);

        String str = null;

        String text1 = new String("Hello Narin");
        System.out.println(text1);

        System.out.println(text.length());

        String upperCase = text.toUpperCase();
        String lowerCase = text.toLowerCase();
        System.out.println(upperCase);
        System.out.println(lowerCase);

        String replace = text.replace(",",".");
        System.out.println(replace);

        String concat = text.concat("").concat(text);
        System.out.println(concat);

        String concat1 =text1 + text;
        System.out.println(concat1);

        String concat2 = "stron " + 10 + true;
        System.out.println(concat2);

        System.out.println(concat1.equals(concat));

    }
}
