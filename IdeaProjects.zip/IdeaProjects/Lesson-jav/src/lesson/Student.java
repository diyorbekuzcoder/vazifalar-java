package lesson;

public class Student {

    int id;
    String name ;
    static String college = "NamSPI";
    public Student(int id, String name){
        this.id =id;
        this.name =name;
    }
    public Student(){

    }


    public void print(){System.out.println(id+ " " + name + " " + college);}
}

