package lesson;

public class StaticKeyWord {
    public static void main(String[] args ){
//        Student student =new Student(1, "Olim");
//        Student student2 =new Student(2, "Alisher");
//        student.print();
//        student2.print();

        Counter counter = new Counter();
        Counter counter1 = new Counter();
        Counter counter2 = new Counter();

    }
}
 