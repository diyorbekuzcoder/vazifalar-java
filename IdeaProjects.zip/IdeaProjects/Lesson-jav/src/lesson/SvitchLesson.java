package lesson;

import java.util.Scanner;


public class SvitchLesson{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//        int day =scanner.nextInt();
        String text =scanner.next();
        switch (text){
        }


//        if (day == 1){
//            System.out.println("Dushanba");
//        } else if (day ==2) {
//            System.out.println("Seshanba");
//        } else if (day ==3){
//            System.out.println("Chorshanba");
//        } else if (day ==4){
//            System.out.println("Payshanba");
//        } else if (day ==5){
//            System.out.println("Juma");
//        } else if (day ==6){
//            System.out.println("Shanba");
//        } else if (day ==7){
//            System.out.println("Yakshanba");
//        } else {
//            System.out.println("bunday kun yo'q ");
//        }




//        switch (day) {
//            case 1:
//                System.out.println("Dushanba");
//                break;
//            case 2:
//                System.out.println("Seshanba");
//                break;
//            case 3:
//                System.out.println("Chorshanba");
//                break;
//            case 4:
//                System.out.println("Pashanba");
//                break;
//            case 5:
//                System.out.println("Juma");
//                break;
//            case 6:
//                System.out.println("Shanba");
//                break;
//            case 7:
//                System.out.println("Yakshanba");
//                break;
//            default:
//            {
//                System.out.println("bunday kun yo'q ");
//            }
//        }


//        switch (day) {
//            case 1, 2, 12:
//                System.out.println("Qish");
//                break;
//            case 3, 4, 5:
//                System.out.println("Bahor");
//                break;
//            case 6, 7, 8:
//                System.out.println("Yoz");
//                break;
//            case 9, 10, 11:
//                System.out.println("Kuz");
//                break;
//            default:
//                System.out.println("bunday oy yo'q");
//        }



    }

}
