package lesson;

public class Calculate {
    static int sum(int a, int b){
        return a+b;

    }
}
