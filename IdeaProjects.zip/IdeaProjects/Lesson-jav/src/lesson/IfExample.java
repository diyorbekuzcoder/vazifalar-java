package lesson;

import java.util.Scanner;

public class IfExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int Grandutishbal = scanner.nextInt();
        int Kantraktutishbal = scanner.nextInt();
        int ball = scanner.nextInt();

//        if (a < 100){
//            System.out.println("Sonimiz 100 dan kichik ");
//        }   else {
//            System.out.println("Sonimiz 100 dan katta");
//        }




//        if ( a % 2 == 0){
//            if (a % 5 == 0){
//                System.out.println(a + "bu sonimiz juft va 5 ga bo'linadi ");
//            } else {
//                System.out.println(a + "bu sonimiz juft va 5 ga bo'linmayadi ");
//            }
//        } else {
//            if (a % 5 == 0){
//                System.out.println(a + "bu sonimz toq va 5 ga bo'linadi");
//            } else {
//                System.out.println(a + "bu sonimz toq lekin 5ga bo'linmaydi");
//            }
//        }


    }
}
