package lesson;

public class MethodOverLoading {
//    public void display (){
//        System.out.println("Method1");
//    }
//
//    public void display (double a){
//        System.out.println("Method1"+ a);
//    }
//
//
//    public void display (double d){
//        System.out.println("Method1"+ d);
//    }
//
//
//    public int add(int a, int d){
//        return a+d;
//    }
//
//    public double add(int a, int d){
//        return a+d;
//    }
//
//    public void sum(int a , long d){
//        System.out.println("int menthod");
//    }
//
//    public void sum(int a , long d){
//        System.out.println("long menthod");
//    }
//
//    public static void main(String[] args) {
//        MethodOverLoading lesson = new MethodOverLoading();
//        lesson.display();
//        lesson.display(1);
//        lesson.display(1.1);
//
//    }
}
