package lesson;

public class IncDecLesson {
    public static void main(String[] args) {
        int n =15;
        int m = 15;
        System.out.println(n++ + ++n);
        System.out.println(m++ + m++);
    }
}
