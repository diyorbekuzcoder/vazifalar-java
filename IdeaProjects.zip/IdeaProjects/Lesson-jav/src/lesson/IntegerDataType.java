package lesson;

public class IntegerDataType {
}
