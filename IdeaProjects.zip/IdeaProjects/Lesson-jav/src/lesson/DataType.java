package lesson;

public class DataType {
    public static void main(String[] agrs) {
    }
}
