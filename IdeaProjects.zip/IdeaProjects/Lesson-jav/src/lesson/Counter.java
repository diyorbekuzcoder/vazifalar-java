package lesson;

public class Counter {
    static int count = 0 ;

    public Counter(){
        count++;
        System.out.println(count);
    }
}
