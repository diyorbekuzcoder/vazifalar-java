package lesson.Vazifalar;

public class ProductCar {
    public static void main(String[] args) {
        Car mercedes = new Car();
        mercedes.getColor("green");
        mercedes.getModel("Mercedes");
        mercedes.getSum("15000$");
        mercedes.getLever("mexanik");


        Car bmw = new Car();
        bmw.getModel("Bmw");
        bmw.getColor("Blue");
        bmw.getSum("13000$");
        bmw.getLever("avtomat");

   }
}
