package lesson.Vazifalar;

public class Car {

    //model
    //color
    //sum

    public void getColor (String color){
        System.out.println(color);
    }

    public void getModel(String model){
        System.out.println(model);
    }

    public void getSum(String sum){
        System.out.println(sum);
    }

    public void getLever(String lever){
        System.out.println(lever);
    }
}
