package lesson.Vazifalar;

  public class MathFunctions {

    static double pi;
    static double e;


    public MathFunctions(double piValue, double eValue) {
        pi = piValue;
        e = eValue;
    }


    public static double circleArea(double radius) {

        return pi * radius * radius;
    }

    public static double exponentialPower(double a) {

        return Math.pow(e, a);
    }
    public static double triangleArea(double a, double b, double c) {

        double s = (a + b + c) / 2;
        double area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
        return area;
    }

    public static void main(String[] args) {

        MathFunctions mathFunctions = new MathFunctions(3.14159, 2.71828);

        double radius = 5;
        double circleArea = MathFunctions.circleArea(radius);
        System.out.println("Circle area with radius " + radius + ": " + circleArea);

        double exponent = 3;
        double expResult = MathFunctions.exponentialPower(exponent);
        System.out.println("e^" + exponent + ": " + expResult);

        double a = 3, b = 4, c = 5;
        double triangleArea = MathFunctions.triangleArea(a, b, c);
        System.out.println("Triangle area with sides " + a + ", " + b + ", " + c + ": " + triangleArea);
    }
  }


