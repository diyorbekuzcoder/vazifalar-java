//package vazifalar;

//// Uchburchak klassini e'lon qilish
//public class uchburchak {
//    // Uchburchak tomonlari
//    private double a; // Gorizontal tomon
//    private double b; // Vertikal tomon
//    private double hypotenuse; // Gipotenuza
//
//    // Konstruktor: uchburchak tomonlarini qabul qiladi
//    public uchburchak(double a, double b) {
//        this.a = a;
//        this.b = b;
//        this.hypotenuse = calculateHypotenuse(); // Gipotenuzani hisoblash
//    }
//
//    // Gipotenuzani hisoblash (Pifagor teoremasi)
//    private double calculateHypotenuse() {
//        return Math.sqrt(a * a + b * b);
//    }
//
//    // Uchburchakning yuzini hisoblash
//    public double calculateArea() {
//        return (a * b) / 2;
//    }
//
//    // Uchburchak perimetrini hisoblash
//    public double calculatePerimeter() {
//        return a + b + hypotenuse;
//    }
//
//    // Tomonlar uchun getter metodlar
//    public double getA() {
//        return a;
//    }
//
//    public double getB() {
//        return b;
//    }
//
//    public double getHypotenuse() {
//        return hypotenuse;
//    }
//
//    // Tomonlarni o'zgartirish uchun setter metodlar
//    public void setA(double a) {
//        this.a = a;
//        this.hypotenuse = calculateHypotenuse(); // Gipotenuzani qayta hisoblash
//    }
//
//    public void setB(double b) {
//        this.b = b;
//        this.hypotenuse = calculateHypotenuse(); // Gipotenuzani qayta hisoblash
//    }
//
//    // Uchburchak ma'lumotlarini ko'rsatish uchun metod
//    public void printTriangleInfo() {
//        System.out.println("Uchburchak tomonlari:");
//        System.out.println("A: " + a + ", B: " + b + ", Gipotenuza: " + hypotenuse);
//        System.out.println("Yuza: " + calculateArea());
//        System.out.println("Perimetr: " + calculatePerimeter());
//    }
//}
