package lesson.Vazifalar;

public class uchburchak {
    //Katet1
    //Katet2
    //Gipatenuza
    //perimetr
    //yuzi

    public void getKatet1 (int katet1){
        System.out.println(katet1);
    }

    public void getKatet2 (int katet2){
        System.out.println(katet2);
    }

    public void getGipatenuza (int gipatenuza){
        System.out.println(gipatenuza);
    }

    public void getPerimetr (int perimetr){
        System.out.println(perimetr);
    }

    public void getYuzi (int yuzi){
        System.out.println(yuzi);
    }

}
