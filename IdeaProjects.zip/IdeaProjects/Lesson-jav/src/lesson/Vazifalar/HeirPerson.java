package lesson.Vazifalar;

public class HeirPerson {
    public static void main(String[] args) {
        Person Abdulla =new Person();
        Abdulla.getIsm("Boltavoy");
        Abdulla.getFamiliya("Teshaboyev");
        Abdulla.getJins("erkak");
        Abdulla.getYoshi(25);
        Abdulla.getVazni(75);
        Abdulla.getBoyi(185);


    }
}
