package lesson.Vazifalar;

public class Person {
    //Ismi
    //Familiyasi
    //Boyi
    //Vazni
    //Yoshi

    public void getIsm (String ism){
        System.out.println(ism);
    }

    public void getFamiliya (String familiya){
        System.out.println(familiya);
    }

    public void getBoyi (int boyi){
        System.out.println(boyi);
    }

    public void getVazni (int vazni){
        System.out.println(vazni);
    }

    public void getYoshi (int yoshi){
        System.out.println(yoshi);
    }

    public void getJins (String jins){
        System.out.println(jins);
    }
}
