//package vazifalar;
//
//public class nusxaburchak {
//    public static void main(String[] args) {
//         To'g'ri burchakli uchburchak obyektini yaratish
//         Uchburchak triangle = new Uchburchak(3, 4);
//        // Natijalarni chop etish
//        System.out.println("Gorizontal tomon (a): " + triangle.getA());
//        System.out.println("Vertikal tomon (b): " + triangle.getB());
//        System.out.println("Gipotenuza: " + triangle.getHypotenuse());
//        System.out.println("Yuza: " + triangle.calculateArea());
//        System.out.println("Perimetr: " + triangle.calculatePerimeter());
//    }
//}
