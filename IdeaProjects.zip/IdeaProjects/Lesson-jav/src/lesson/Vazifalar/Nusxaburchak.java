package lesson.Vazifalar;

public class Nusxaburchak {
    public static void main(String[] args) {
        System.out.println("Perimetr: " + new Nusxaburchak().perimetr());
        System.out.println("Yuza: " + new Nusxaburchak().yuzasi());
    }

    public double yuzasi() {
        int i = (1 * 2) / 2; // Matematik amallar to'g'ri yozilgan
        return i;
    }

    public double perimetr() {
        return 1 + 2 + 3; // Oddiy perimetr hisoblash
    }
}

