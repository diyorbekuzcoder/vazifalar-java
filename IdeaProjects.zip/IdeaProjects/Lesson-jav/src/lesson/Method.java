package lesson;

public class Method {

}
