package lesson;

import java.util.Scanner;

public class ForExample  {

    public static void main(String[] args) {

        // Sonlarni yig'indisini topish
        // Sonlarni kopaytmasini topish
        Scanner scanner = new Scanner(System.in);
        int n =scanner.nextInt();
        int sum = 1;
//        for (int i = 1; i <=n ; i++) {
//            System.out.println(" sum = " + sum + " + " + i);
//            sum += i;// sum = sum + i
//        }
        for (int i = 1; i <=n ; i++) {
            sum *= i ; //sum = sum *i
        }
        System.out.println(sum);
    }
}













