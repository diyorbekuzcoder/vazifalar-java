package lesson;

public class OperatorsExample {
    public static void main(String[] args) {
        boolean open =true;
        boolean close = false;

        // not ,and ,xor , or

        boolean b =!false;
        System.out.println(b);

        Boolean b1 =true ||  true;
        Boolean b2 =true || false;
        Boolean b3 =false || false;
        Boolean b4 =false || true;

        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        System.out.println(b4);

        boolean b5 = open && !(close || b);
        System.out.println(b5);

    }
}
