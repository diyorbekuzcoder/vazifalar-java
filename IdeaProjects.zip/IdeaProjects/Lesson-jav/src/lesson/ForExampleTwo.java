package lesson;

import java.util.Scanner;

public class ForExampleTwo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int sum = 0;
        for (int i = 1; i < n; i++) {
            if (i % 5 == 0 || i % 3 ==0){
                System.out.println(i);
                sum += i;

            }
        }
    }
}
