package lesson;

import java.util.Scanner;

public class FloatingPointingDataType {
    public static void main(String[] args) {
        //double,float

        Scanner scanner = new Scanner(System.in);
        double n = scanner.nextDouble();
        int n1 = scanner.nextInt();
        float f = scanner.nextFloat();
        System.out.println("birinchi son " + n);
        System.out.println("ikkinchi son " + n1);
        System.out.println("uchinchi son " + f);

        double one = 1.0;
        double number = 1.0 + 1;
        System.out.println(number);
        double pi = 3.14566;


        double ex = 5e-3;  // 5*10 ^ -3 ==0.005
        System.out.println(ex);
        double ex1 =0.1e2; //0.1 * 10 ^ 2
        System.out.println(ex1);

        double a = 5/4;
        System.out.println(a);
        double a1 = 5.0/4;
        System.out.println(a1);

        double d = 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1 + 0.1;
        System.out.println(d);

        double d1 = 3.3/3;
        System.out.println(d1);

    }
}
