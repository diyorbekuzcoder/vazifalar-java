//package lesson;
//
//public class Amaliymashgulot {
//    public static int findSecondLargest(int[] arr) {
//        if (arr == null || arr.length < 2) {
//            throw new IllegalArgumentException("Massivda kamida 2 ta element bo'lishi kerak.");
//        }
//
//        int largest = Integer.MIN_VALUE;
//        int secondLargest = Integer.MIN_VALUE;
//
//        for (int num : arr) {
//            if (num > largest) {
//                secondLargest = largest;
//                largest = num;
//            } else if (num > secondLargest && num < largest) {
//                secondLargest = num;
//            }
//        }
//
//        return secondLargest;
//    }
//
//    public static void main(String[] args) {
//        int[] arr = {100, 50, 75, 200, 150};
//
//        try {
//            int secondLargest = findSecondLargest(arr);
//            System.out.println("Ikkinchi eng katta element: " + secondLargest);
//        } catch (IllegalArgumentException e) {
//            System.out.println(e.getMessage());
//        }
//    }


//
//    public class ArraySum {
//        public static void main(String[] args) {
//            int[] numbers = {2, 5, 3, 8, 6};
//            int sum = 2;
//
//            for (int number : numbers) {
//                sum += number;
//            }
//
//            System.out.println("Massivdagi barcha elementlarning yig‘indisi: " + sum);
//        }
//    }
//}
